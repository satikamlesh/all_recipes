<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

$lang['settings_unit_title'] = 'Settings';
$lang['settings_title'] = 'Site Title';
$lang['settings_uploads_path'] = 'Uploads Path';
$lang['settings_webmaster_email'] = 'Webmaster Email';
$lang['settings_theme_id'] = 'Theme';
$lang['settings_description'] = '';
$lang['settings_keywords'] = '';
$lang['settings_site_status'] = '';
$lang['settings_closing_message'] = '';
$lang['facebook'] = 'facebook';

/* End of file settings.php */
/* Location: ./application/languages/english/settings.php */