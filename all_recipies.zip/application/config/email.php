<?php

$config['protocol'] = 'smtp';
$config['charset'] = 'utf-8';
$config['smtp_host'] = '';
$config['smtp_user'] = '';
$config['smtp_pass'] = '';
$config['smtp_port'] = '587';
