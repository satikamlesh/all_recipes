<?php

class Newsletters_model extends CIF_model
{
    public $_table = 'newsletters';
    public $_primary_keys = array('id');


}
