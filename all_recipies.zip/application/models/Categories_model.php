<?php

class Categories_model extends CIF_model
{
    public $_table = 'categories';
    public $_primary_keys = array('category_id');


}
