<?php

class Sliders_model extends CIF_model
{
    public $_table = 'sliders';
    public $_primary_keys = array('slider_id');


}
